#include<stdio.h>
#include<stdlib.h>

FILE *fin;
FILE *fout;

typedef struct AVLTreeNode AVLNode;
typedef int Element;

struct AVLTreeNode{
	Element element;
	AVLNode* left;
	AVLNode* right;
	int height;
};

//구현하면 좋은 함수
//getHeight, max, updateHeight, rebalance

int getHeight(AVLNode* node) {
    return node ? node->height : 0;
}

int max(int a, int b) {
    return (a > b) ? a : b;
}

void updateHeight(AVLNode* node) {
    if (node!=NULL) {
        node->height = 1 + max(getHeight(node->left), getHeight(node->right));
    }
}

AVLNode* findMin(AVLNode* T) {
    while (T->left != NULL) 
        T = T->left;
    return T;
}

AVLNode* RotateRight(AVLNode* node){
    //우회전
    //node->left를 L이라 할 때
    //p->left를 L->right로
    //L->right를 p로
    //p와 L의 height update
    //return L
    AVLNode* L = node->left;
    node->left = L->right;
    L->right = node;
    updateHeight(node);
    updateHeight(L);
    return L;
}

AVLNode* RotateLeft(AVLNode* node){
    //좌회전
    //node->right를 R이라 할 때
    //p->right를 R->left로
    //R->left를 p로
    //p와 R의 height update
    //return R
    //rotateRight에서 전부 반대방향
    AVLNode* R = node->right;
    node->right = R->left;
    R->left = node;
    updateHeight(node);
    updateHeight(R);
    return R;
    return NULL;
}

AVLNode* rebalance(AVLNode* T){
    // if 왼쪽 높이 > 오른쪽 높이 + 1 일 경우
    //     만약 LR 케이스면 좌회전
    //     우회전
    // elif 왼쪽 높이 + 1 < 오른쪽 높이 일 경우 
    //     만약 RL 케이스면 우회전
    //     좌회전
    // 높이 갱신
    updateHeight(T);
    int balance = getHeight(T->left) - getHeight(T->right);
    if (balance > 1) {
        if (getHeight(T->left->right) > getHeight(T->left->left)) {
            T->left = RotateLeft(T->left);
        }
        T = RotateRight(T);
    } else if (balance < -1) {
        if (getHeight(T->right->left) > getHeight(T->right->right)) {
            T->right = RotateRight(T->right);
        }
        T = RotateLeft(T);
    }
    return T;
}


AVLNode* Insert(Element X, AVLNode* T){
    //NULL이면 AVLNode 생성 후 반환
    //T->element != X면 recursive하게 찾고,
    //T->left = Insert(X, T->left) 형태로 포인터 갱신
    //T->element == X면 삽입 오류
    //rebalance 해줘야 함(삽입 시 균형 망가질 수 있음)
    if (T == NULL) {
        T = (AVLNode*)malloc(sizeof(AVLNode));
        T->element = X;
        T->left = T->right = NULL;
        T->height = 1;
        return T;
    }
    if (X < T->element) {
        T->left = Insert(X, T->left);
    } else if (X > T->element) {
        T->right = Insert(X, T->right);
    } else {
        fprintf(fout, "insertion error : %d is already in the tree\n", X);
        return T;
    }
    return rebalance(T);
}

AVLNode* Delete(Element X, AVLNode* T){
    //NULL이면 오류
    //Insert와 동일하게 recursive
    //T->element == X면 BST 삭제 과정
    //마지막으로 해당 노드를 서브트리의 루트로 rebalance
    if (T == NULL) {
        fprintf(fout, "deletion error : %d is not in the tree\n", X);
        return T;
    }
    if (X < T->element) {
        T->left = Delete(X, T->left);
    } else if (X > T->element) {
        T->right = Delete(X, T->right);
    } else {
        if (T->left == NULL || T->right == NULL) {
            AVLNode* temp = T->left ? T->left : T->right;
            if (temp == NULL) {
                temp = T;
                T = NULL;
            } else {
                *T = *temp;
            }
            free(temp);
        } else {
            AVLNode* temp;
            while (T->right->left != NULL) 
                T->right = T->right->left;
                temp = T->right;
            T->element = temp->element;
            T->right = Delete(temp->element, T->right);
        }
    }
    if (T == NULL) return T;
    return rebalance(T);
}

void PrintInorder(AVLNode* T){
    //inorder로 출력
    if (T != NULL) {
        PrintInorder(T->left);
        fprintf(fout, "%d(%d) ", T->element, T->height);
        PrintInorder(T->right);
    }
}    

void DeleteTree(AVLNode* T){
    //postorder로 free
    if (T != NULL) {
        DeleteTree(T->left);
        DeleteTree(T->right);
        free(T);
    }
}

int main(int argc, char *argv[]){
	fin = fopen(argv[1], "r");
	fout = fopen(argv[2], "w");
	AVLNode* Tree = NULL;
	char cv;
	int key;

	while(!feof(fin)){
		fscanf(fin, "%c", &cv);
		switch(cv){
			case 'i':
				fscanf(fin, "%d\n", &key);
				Tree = Insert(key, Tree);
				break;
			case 'd':
				fscanf(fin, "%d\n", &key);
				Tree = Delete(key, Tree);
				break;
		}
		PrintInorder(Tree);
		fprintf(fout, "\n");
	}

	DeleteTree(Tree);
	fclose(fin);
	fclose(fout);

	return 0;
}
